package com.example.experiment1

data class ImageData(val id:Int , val image: String) {

}

package com.example.experiment1

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.io.ByteArrayOutputStream
import java.io.InputStream

class Utils {
    fun  getImageByte( bitmap:Bitmap):ByteArray{
        var stream =ByteArrayOutputStream();

        if(stream.toByteArray().size > 100000){
            val len : Int = bitmap.width;
            val bre : Int = bitmap.height;
            val resize:Bitmap = Bitmap.createScaledBitmap(bitmap, len * 0.7 as Int , bre * 0.7 as Int ,true);
            resize.compress(Bitmap.CompressFormat.PNG,0,stream);
        }else{
            bitmap.compress(Bitmap.CompressFormat.PNG,0,stream);
        }
        return  stream.toByteArray();
    }
    fun getImage(image:ByteArray):Bitmap{
        return BitmapFactory.decodeByteArray(image,0,image.size)
    }
    fun getBytes(ipstream:InputStream):ByteArray{
        var stream = ByteArrayOutputStream()
        var streamSize: Int =1024
        var buffer= ByteArray(streamSize)
        var len:Int =0;
        while ((len == ipstream.read(buffer))){
            stream.write(buffer,0,len)
        }
        return stream.toByteArray()
    }
}
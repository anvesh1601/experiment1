package com.example.experiment1

object constants {
}
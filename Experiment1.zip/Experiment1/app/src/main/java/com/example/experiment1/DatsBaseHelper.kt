package com.example.experiment1

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.security.AccessControlContext

class DatsBaseHelper(context: Context?):SQLiteOpenHelper(context,DATABASE_NAME,null,3) {
    companion object co{
        private val DATABASE_NAME="ImageDB";
        private val TABLE_NAME= "ImageTable";
        private val _ID = "COL_ID"
        private val Image = "Image"
    }
    override fun onCreate(Db: SQLiteDatabase) {
         val createTable= ("CREATE TABLE "+ TABLE_NAME+"("+ _ID+" INTEGER PRIMARY KEY AUTOINCREMENT, "
                 + Image+" long text"+")")
        Db.execSQL(createTable);
    }

    override fun onUpgrade(Db: SQLiteDatabase, p1: Int, p2: Int) {
        Db.execSQL("DROP TABLE IF EXISTS "+ TABLE_NAME);
    onCreate(Db)

    }
    fun insertRecord( image:String):Long{
        val db= this.writableDatabase
        val cv= ContentValues();
        cv.put(Image,image)
        val id = db.insert(TABLE_NAME,null,cv);
        db.close();
        return id;
    }
    fun getRecords():ArrayList<ImageData>{
        var list:ArrayList<ImageData> = ArrayList<ImageData>();
        val db=this.readableDatabase
        val quiery = "select * from "+ TABLE_NAME;
        var result=db.rawQuery(quiery,null);
        if (result.moveToFirst()){
            do{
                val id= result.getInt(0)
                val image:String = result.getString(1);
                val imageData:ImageData = ImageData(id,image);
                list.add(imageData);
            }while (result.moveToNext())
        }
        db.close();
        return list;
    }
    fun deleteAll(){
        var list:MutableCollection<ImageData> = ArrayList<ImageData>();
        val db=this.writableDatabase
        val quiery = "delete  from "+ TABLE_NAME;
        db.execSQL(quiery);
        db.close()
    }
}
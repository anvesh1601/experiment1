package com.example.experiment1

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.drawable.Drawable
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.MediaStore
import android.view.View
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.toBitmap
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.io.IOException

class MainActivity : AppCompatActivity() {

    private lateinit var pick_image : Button
    private lateinit var  imageView: ImageView

    private var  uri: Uri? = null
    val REQUEST_CODE = 100
    private  val CAMERA_REQUEST_CODE=100
    private  val STORAGE_REQUEST_CODE=101
    private  val IMAGE_PICK_CAMERA_CODE=102
    private  val IMAGE_PICK_GALLERY_CODE=102
    private lateinit var cameraPermission:Array<String>
    private lateinit var storagePermission:Array<String>
    private  var imageUri: Uri? =null
private  lateinit var  recyclerView:RecyclerView;
    private lateinit var list:ArrayList<ImageData>;

    lateinit var Dbhelper:DatsBaseHelper
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        cameraPermission = arrayOf(Manifest.permission.CAMERA,Manifest.permission.WRITE_EXTERNAL_STORAGE)
        storagePermission= arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        recyclerView = findViewById(R.id.recyclerView)
        recyclerView.layoutManager=LinearLayoutManager(this);
        recyclerView.setHasFixedSize(true)

        Dbhelper= DatsBaseHelper(this);
        Dbhelper.deleteAll();

        imageView =findViewById(R.id.imageView);
        imageView.visibility=View.GONE;
        pick_image = findViewById(R.id.picK_Image);
        pick_image.setOnClickListener {
            //getCameraPermissions()
            galleryPermissioncheck();

        }
readData();
    }
   fun readData(){
       list= Dbhelper.getRecords() as ArrayList<ImageData>;

       Toast.makeText(this, " "+list.size, Toast.LENGTH_SHORT).show()
        recyclerView.adapter= ImageAdapter(list);
    }
    private fun insertData(byteArray: String) {
        try {

            val id = Dbhelper.insertRecord(byteArray);
            readData();
            Toast.makeText(this, "Data added"+id, Toast.LENGTH_SHORT).show()

        }catch (e:IOException){
            e.printStackTrace()
            print(imageUri);
        }
    }

    private fun checkStoragePermissions(): Boolean {
return ContextCompat.checkSelfPermission(this,Manifest.permission.WRITE_EXTERNAL_STORAGE)== PackageManager.PERMISSION_GRANTED
    }



    private fun requestCameraPermissions() {
        ActivityCompat.requestPermissions(this,cameraPermission,CAMERA_REQUEST_CODE)
    }
    private fun requestStoragePermissions() {

        ActivityCompat.requestPermissions(this,storagePermission,STORAGE_REQUEST_CODE)
    }
    private fun checkCameraPermissions(): Boolean {
        val result = ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA)== PackageManager.PERMISSION_GRANTED
        val result2 = ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA)== PackageManager.PERMISSION_GRANTED
return result && result2;
    }

    fun galleryPermissioncheck(){
        if(!checkStoragePermissions()){
            requestStoragePermissions()
        }else{
            openGallery()
        }
    }
    private fun openGallery(){

        val intent  = Intent(Intent.ACTION_PICK)
        intent.type="image/*"

        startActivityForResult(intent,REQUEST_CODE);
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode == Activity.RESULT_OK ){
             if(requestCode==IMAGE_PICK_GALLERY_CODE){
                 imageUri=data?.data;
             }

            imageUri=data?.data;
            imageView.setImageURI(data?.data);
            var drawable:Drawable =  imageView.drawable;
            var bitmap=drawable.toBitmap();
            var byteArray = Utils().getImageByte(bitmap);
            insertData(imageUri.toString())



        }else{
            Toast.makeText(this, "coudn't fetch", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when(requestCode){
            CAMERA_REQUEST_CODE ->{
                if(grantResults.isNotEmpty()){
                    val cameraaccepted = grantResults[0] == PackageManager.PERMISSION_GRANTED;
                    val storageAccepte = grantResults[1] == PackageManager.PERMISSION_GRANTED;
                    if(cameraaccepted && storageAccepte){
                       // pickFromCamera();
                    }else{
                        Toast.makeText(this, "Permissions  Required", Toast.LENGTH_SHORT).show()
                    }
                }

            }
            STORAGE_REQUEST_CODE ->{
                if(grantResults.isNotEmpty()){

                    val storageAccepte = grantResults[0] == PackageManager.PERMISSION_GRANTED;
                    if( storageAccepte){
                        openGallery();
                    }else{
                        Toast.makeText(this, "Permissions  Required", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }
}

